package com.example.booking_app.Domain;

public class Slideritems {
    private String url;

    public Slideritems(){

    }
    public String getUrl(){
        return url;
    }
    public void setUrl(String url){
        this.url=url;
    }
}
